﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => "Server=GEORGI\\SQLEXPRESS;Database=BookShop;Integrated Security=True;";// <---- Put Your Connection String !
    }
}
