﻿namespace PetClinic.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=GEORGI\SQLEXPRESS;Database=PetClinic;Trusted_Connection=True";
    }
}
