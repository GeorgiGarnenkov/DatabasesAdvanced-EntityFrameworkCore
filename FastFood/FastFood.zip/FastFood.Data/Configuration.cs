namespace FastFood.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=GEORGI\SQLEXPRESS;Database=FastFood;Trusted_Connection=True";
	}
}