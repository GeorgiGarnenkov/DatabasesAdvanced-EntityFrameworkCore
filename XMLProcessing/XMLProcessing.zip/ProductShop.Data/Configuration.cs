﻿namespace ProductShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => 
            "Server=.;Database=SoftUni;Integrated Security=True;"; // <---- Put Your Connection String !
    }
}