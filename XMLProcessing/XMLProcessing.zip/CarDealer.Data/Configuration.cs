﻿namespace CarDealer.Data
{
    internal class Configuration
    {
        internal static string ConnectionString =>
            "Server=GEORGI\\SQLEXPRESS;Database=CarDealerDB;Integrated Security=True;"; // <---- Put Your Connection String !
    }
}